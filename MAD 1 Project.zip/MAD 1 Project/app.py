from flask import Flask, render_template
from models.db import db, init_db
from config import Config
import os
from datetime import date  # Add this import

# Import blueprints
from routes.auth_routes import auth_bp
from routes.user_routes import user_bp
from routes.quiz_routes import quiz_bp
from routes.admin_routes import admin_bp

# Initialize the Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
init_db(app)

# Create charts folder if it doesn't exist
def create_charts_folder():
    charts_dir = os.path.join(app.static_folder, 'charts')
    if not os.path.exists(charts_dir):
        os.makedirs(charts_dir)

create_charts_folder()

@app.context_processor
def inject_current_date():
    return {'current_date': date.today()}  

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(user_bp)
app.register_blueprint(quiz_bp)
app.register_blueprint(admin_bp)

# Home route
@app.route("/")
def home():
    return render_template("home.html")

# Error handling routes
@app.errorhandler(404)
def page_not_found(error):
    return render_template("errors/404.html"), 404

@app.errorhandler(500)
def internal_server_error(error):
    return render_template("errors/500.html"), 500

# Run the app
if __name__ == "__main__":
    app.run(debug=True)  # Set to False in production
