from flask_sqlalchemy import SQLAlchemy

# Initialize SQLAlchemy instance
db = SQLAlchemy()

# Import models to ensure they are registered before database initialization
from .db import User, Subject, Chapter, Quiz, Question, Option

# Function to initialize the database within the Flask app
def init_db(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()
