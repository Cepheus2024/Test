from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from pytz import timezone  # Add this import for timezone handling
from werkzeug.security import generate_password_hash

db = SQLAlchemy()

# User Model (For Students & Admins)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    qualification = db.Column(db.String(100))
    dob = db.Column(db.Date, nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')  # Add role attribute

    scores = db.relationship('Score', backref='user', lazy=True, cascade="all, delete-orphan")

# Subject Model
class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)

    chapters = db.relationship('Chapter', backref='subject', lazy=True, cascade="all, delete-orphan")

# Chapter Model
class Chapter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)

    quizzes = db.relationship('Quiz', backref='chapter', lazy=True, cascade="all, delete-orphan")

# Quiz Model
class Quiz(db.Model):
    id = db.Column(db.Integer, primary_key=True)  # Ensure no autoincrement=True here
    title = db.Column(db.String(200), nullable=False)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapter.id'), nullable=False)
    date_of_quiz = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)  # Store date & time
    time_duration = db.Column(db.Integer, nullable=False)  # Duration in minutes
    total_score = db.Column(db.Integer, nullable=False, default=0)  # Total score dynamically updated

    questions = db.relationship('Question', backref='quiz', lazy=True, cascade="all, delete-orphan")
    scores = db.relationship('Score', backref='quiz', lazy=True, cascade="all, delete-orphan")

    def update_total_score(self):
        """Update the total score of the quiz based on the sum of marks for all questions."""
        self.total_score = sum(question.marks for question in self.questions)
        db.session.commit()

# Question Model
class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    correct_option = db.Column(db.Integer, nullable=True)  # Stores correct option (1-4) for MCQs
    correct_answer = db.Column(db.String(255), nullable=True)  # Stores correct answer for numerical questions
    question_type = db.Column(db.String(50), nullable=False)  # 'mcq' or 'numerical'
    marks = db.Column(db.Integer, nullable=False, default=1)  # New column for individual question marks

    options = db.relationship('Option', backref='question', lazy=True, cascade="all, delete-orphan")

# Option Model (For Multiple Choice Answers)
class Option(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id'), nullable=False)
    text = db.Column(db.String(255), nullable=False)

# Score Model (Stores User Quiz Attempts)
class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    time_stamp_of_attempt = db.Column(db.DateTime, default=lambda: datetime.now(timezone('Asia/Kolkata')))  # Set timezone to IST
    total_scored = db.Column(db.Integer, nullable=False)

# Function to Initialize the Database
def init_db(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()  # Creates all tables if they don’t exist
        create_default_admin()

def create_default_admin():
    admin_email = "admin@quizmaster.com"
    admin_password = generate_password_hash("admin123")
    admin_user = User.query.filter_by(email=admin_email).first()

    if not admin_user:
        new_admin = User(full_name="Admin User", email=admin_email, password=admin_password, qualification="Admin", dob=datetime(2000, 1, 1).date(), role="admin")
        db.session.add(new_admin)
        db.session.commit()
