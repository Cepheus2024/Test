from flask import Blueprint

# Import all blueprints
from .admin_routes import admin_bp
from .user_routes import user_bp
from .auth_routes import auth_bp
from .quiz_routes import quiz_bp

# Create a list of blueprints
blueprints = [admin_bp, user_bp, auth_bp, quiz_bp]

def register_blueprints(app):
    """Register all blueprints in the Flask app."""
    for bp in blueprints:
        app.register_blueprint(bp)
