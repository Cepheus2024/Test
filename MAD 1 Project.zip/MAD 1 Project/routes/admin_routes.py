from flask import Blueprint, render_template, redirect, url_for, session, flash, request, jsonify
from models.db import db, User, Subject, Chapter, Quiz, Question, Score, Option
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

# Route for admin dashboard
@admin_bp.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    stats = {
        "total_users": User.query.count(),
        "total_subjects": Subject.query.count()
    }
    return render_template('admin/admin_dashboard.html', stats=stats)

# Route for admin summary statistics
@admin_bp.route('/admin/summary')
def admin_summary_statistics():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    stats = {
        "total_users": User.query.count(),
        "total_subjects": Subject.query.count()
    }

    subjects = Subject.query.all()
    subject_chapter_quiz_data = []
    for subject in subjects:
        chapters = Chapter.query.filter_by(subject_id=subject.id).all()
        chapter_data = []
        quiz_count = 0
        for chapter in chapters:
            quizzes = Quiz.query.filter_by(chapter_id=chapter.id).all()
            quiz_count += len(quizzes)
            chapter_data.append({
                'chapter': chapter,
                'quizzes': quizzes,
                'quiz_count': len(quizzes)
            })
        subject_chapter_quiz_data.append({
            'subject': subject,
            'chapters': chapter_data,
            'chapter_count': len(chapters),
            'quizzes': quiz_count
        })

    return render_template('admin/admin_summary_statistics.html', stats=stats, subject_chapter_quiz_data=subject_chapter_quiz_data)

# Route to view all users
@admin_bp.route('/admin/users')
def view_all_users():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    users = User.query.all()
    return render_template('admin/view_all_users.html', users=users)

# Route to delete a user (prevents admin deletion)
@admin_bp.route('/admin/users/delete/<int:user_id>')
def delete_user(user_id):
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    user = User.query.get_or_404(user_id)
    
    # Prevent deleting an admin account
    if user.email == "admin@quizmaster.com":
        flash('Admin account cannot be deleted.', 'danger')
        return redirect(url_for('admin.view_all_users'))

    db.session.delete(user)
    db.session.commit()
    flash('User deleted successfully.', 'success')
    return redirect(url_for('admin.view_all_users'))

# Route to add a new subject
@admin_bp.route('/admin/subject/add', methods=['GET', 'POST'])
def subject_addition():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    if request.method == 'POST':
        name = request.form['subject_name']
        description = request.form['subject_description']
        subject = Subject(name=name, description=description)
        db.session.add(subject)
        db.session.commit()
        flash('Subject added successfully!', 'success')
        return redirect(url_for('admin.subjects'))  # Redirect to subject list

    return render_template('admin/subject_addition.html')

# Route to edit an existing subject
@admin_bp.route('/admin/subject/edit/<int:subject_id>', methods=['GET', 'POST'])
def subject_edit(subject_id):
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    subject = Subject.query.get_or_404(subject_id)
    if request.method == 'POST':
        subject.name = request.form['subject_name']
        subject.description = request.form['subject_description']
        db.session.commit()
        flash('Subject updated successfully!', 'success')
        return redirect(url_for('admin.subjects'))

    return render_template('admin/subject_edit.html', subject=subject)

# Route to manage subjects
@admin_bp.route('/admin/subjects', methods=['GET', 'POST'])
def subjects():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    search_query = request.args.get('query', '').strip()
    if search_query:
        subjects = Subject.query.filter(Subject.name.ilike(f"%{search_query}%")).all()
        if not subjects:
            flash(f'No subjects found for "{search_query}".', 'warning')
    else:
        subjects = Subject.query.all()

    return render_template('admin/subjects.html', subjects=subjects, search_query=search_query)

# Route to delete a subject
@admin_bp.route('/admin/subject/delete/<int:subject_id>', methods=['POST', 'GET'])
def subject_delete(subject_id):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to delete a subject.", "danger")
        return redirect(url_for('auth.admin_login'))

    subject = Subject.query.get_or_404(subject_id)
    
    # Ensure safe deletion
    db.session.delete(subject)
    db.session.commit()
    flash('Subject deleted successfully!', 'success')

    return redirect(url_for('admin.subjects'))

# Route to manage quizzes
@admin_bp.route('/admin/quizzes', methods=['GET', 'POST'])
def quizzes():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    search_query = request.args.get('query', '').strip()
    if search_query:
        quizzes = Quiz.query.join(Chapter).join(Subject).filter(
            (Quiz.title.ilike(f"%{search_query}%")) |
            (Chapter.name.ilike(f"%{search_query}%")) |
            (Subject.name.ilike(f"%{search_query}%"))
        ).all()
        if not quizzes:
            flash(f'No quizzes found for "{search_query}".', 'warning')
    else:
        quizzes = Quiz.query.all()

    # Include subject and chapter information
    quizzes_with_details = []
    for quiz in quizzes:
        subject_name = quiz.chapter.subject.name if quiz.chapter and quiz.chapter.subject else 'No Subject'
        chapter_name = quiz.chapter.name if quiz.chapter else 'No Chapter'
        quizzes_with_details.append({
            'id': quiz.id,
            'title': quiz.title,
            'subject_name': subject_name,
            'chapter_name': chapter_name,
            'question_count': len(quiz.questions)
        })

    return render_template('admin/quizzes.html', quizzes=quizzes_with_details, search_query=search_query)

# Route to edit a question
@admin_bp.route('/admin/question/edit/<int:question_id>', methods=['GET', 'POST'])
def question_edit(question_id):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to edit a question.", "danger")
        return redirect(url_for('auth.admin_login'))

    question = Question.query.get_or_404(question_id)

    if request.method == 'POST':
        question.text = request.form['question_text']
        question.marks = int(request.form.get('marks', question.marks))  # Update marks

        # Update options for MCQ questions
        if question.question_type == 'mcq':
            for i in range(4):
                option_text = request.form.get(f'option{i+1}')
                if i < len(question.options):
                    question.options[i].text = option_text
                else:
                    new_option = Option(question_id=question.id, text=option_text)
                    db.session.add(new_option)

            # Update correct option
            question.correct_option = int(request.form['correct_option'])

        # Update correct answer for numerical questions
        elif question.question_type == 'numerical':
            question.correct_answer = request.form['correct_answer']

        db.session.commit()

        # Update total score of the quiz
        question.quiz.update_total_score()

        flash('Question updated successfully!', 'success')
        return redirect(url_for('admin.quiz_edit', quiz_id=question.quiz_id))

    return render_template('admin/question_edit.html', question=question)

# Route to add a question to a quiz
@admin_bp.route('/admin/questions/add', methods=['GET', 'POST'])
def questions_addition():
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to add questions.", "danger")
        return redirect(url_for('auth.admin_login'))

    quizzes = Quiz.query.all()  # Fetch all quizzes

    if request.method == 'POST':
        quiz_id = request.form.get('quiz_id')
        question_text = request.form.get('question_text')
        marks = request.form.get('marks', 1)  # Default marks to 1 if not provided
        question_type = request.form.get('question_type')
        correct_option = request.form.get('correct_option')
        correct_answer = request.form.get('correct_answer')

        # Validate Quiz Selection
        quiz = Quiz.query.get(quiz_id)
        if not quiz:
            flash('Invalid Quiz ID!', 'danger')
            return redirect(url_for('admin.questions_addition'))

        # Create the question
        new_question = Question(
            quiz_id=quiz_id,
            text=question_text,
            question_type=question_type,
            marks=int(marks)
        )
        db.session.add(new_question)
        db.session.commit()

        if question_type == 'mcq':
            if not correct_option:
                flash('Correct option is required for MCQ.', 'danger')
                return redirect(url_for('admin.questions_addition'))

            # Add Options
            option_ids = []
            for i in range(1, 5):
                option_text = request.form.get(f'option{i}')
                if option_text:
                    new_option = Option(question_id=new_question.id, text=option_text)
                    db.session.add(new_option)
                    db.session.flush()  # Get the ID of the option before committing
                    option_ids.append(new_option.id)
            db.session.commit()  # Commit options before setting the correct option

            # Set the correct option after options are added
            correct_option_index = int(correct_option) - 1
            if 0 <= correct_option_index < len(option_ids):
                new_question.correct_option = option_ids[correct_option_index]
                db.session.commit()
            else:
                flash('Invalid correct option selected.', 'danger')
                return redirect(url_for('admin.questions_addition'))

        elif question_type == 'numerical':
            if not correct_answer:
                flash('Correct answer is required for numerical questions.', 'danger')
                return redirect(url_for('admin.questions_addition'))
            new_question.correct_answer = correct_answer
            db.session.commit()

        # Update total score of the quiz
        quiz.update_total_score()

        flash('Question added successfully!', 'success')
        return redirect(url_for('admin.quiz_edit', quiz_id=quiz_id))

    return render_template('admin/questions_addition.html', quizzes=quizzes)

# Route to edit a chapter
@admin_bp.route('/admin/chapter/edit/<int:chapter_id>', methods=['GET', 'POST'])
def chapter_edit(chapter_id):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to edit a chapter.", "danger")
        return redirect(url_for('auth.admin_login'))

    chapter = Chapter.query.get_or_404(chapter_id)

    if request.method == 'POST':
        chapter.name = request.form['chapter_name']
        chapter.description = request.form['chapter_description']
        db.session.commit()
        flash('Chapter updated successfully!', 'success')
        return redirect(url_for('admin.chapters'))  # Redirect to chapter list

    return render_template('admin/chapter_edit.html', chapter=chapter)

# Route to add a new chapter
@admin_bp.route('/admin/chapters/add', methods=['GET', 'POST'])
@admin_bp.route('/admin/subject/<int:subject_id>/chapters/add', methods=['GET', 'POST'])
def chapters_addition(subject_id=None):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to add a chapter.", "danger")
        return redirect(url_for('auth.admin_login'))

    subjects = Subject.query.all()  # Fetch all subjects

    if request.method == 'POST':
        subject_id = request.form['subject_id']
        chapter_name = request.form['chapter_name']
        chapter_description = request.form['chapter_description']

        subject = Subject.query.get(subject_id)
        if not subject:
            flash('Invalid subject selected!', 'danger')
            return redirect(url_for('admin.chapters_addition'))

        new_chapter = Chapter(subject_id=subject_id, name=chapter_name, description=chapter_description)
        db.session.add(new_chapter)
        db.session.commit()
        flash('Chapter added successfully!', 'success')
        return redirect(url_for('admin.view_chapters', subject_id=subject_id))  # Redirect to chapters of the specific subject

    selected_subject = Subject.query.get(subject_id) if subject_id else None
    return render_template('admin/chapters_addition.html', subjects=subjects, selected_subject=selected_subject)

# Route to view chapters for a specific subject
@admin_bp.route('/admin/subject/<int:subject_id>/chapters', methods=['GET', 'POST'])
def view_chapters(subject_id):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to view chapters.", "danger")
        return redirect(url_for('auth.admin_login'))

    subject = Subject.query.get_or_404(subject_id)
    search_query = request.args.get('query', '').strip()
    if search_query:
        chapters = Chapter.query.filter(Chapter.subject_id == subject_id, Chapter.name.ilike(f"%{search_query}%")).all()
        if not chapters:
            flash(f'No chapters found for "{search_query}".', 'warning')
    else:
        chapters = Chapter.query.filter_by(subject_id=subject_id).all()

    return render_template('admin/view_chapters.html', subject=subject, chapters=chapters, search_query=search_query)

# Route to manage all chapters
@admin_bp.route('/admin/chapters', methods=['GET', 'POST'])
def chapters():
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to view chapters.", "danger")
        return redirect(url_for('auth.admin_login'))

    search_query = request.args.get('query', '').strip()
    if search_query:
        chapters = Chapter.query.filter(Chapter.name.ilike(f"%{search_query}%")).all()
        if not chapters:
            flash(f'No chapters found for "{search_query}".', 'warning')
    else:
        chapters = Chapter.query.all()

    return render_template('admin/chapters.html', chapters=chapters, search_query=search_query)

# Route to delete a chapter
@admin_bp.route('/admin/chapter/delete/<int:chapter_id>', methods=['POST', 'GET'])
def chapter_delete(chapter_id):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to delete a chapter.", "danger")
        return redirect(url_for('auth.admin_login'))

    chapter = Chapter.query.get_or_404(chapter_id)
    
    # Ensure safe deletion
    db.session.delete(chapter)
    db.session.commit()
    flash('Chapter deleted successfully!', 'success')

    return redirect(url_for('admin.chapters'))

# Route to create a new quiz
@admin_bp.route('/admin/quiz/create', methods=['GET', 'POST'])
def quiz_creation():
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    if request.method == 'POST':
        title = request.form['quiz_title']
        chapter_id = request.form['chapter_id']
        date_of_quiz = datetime.strptime(request.form['date_of_quiz'], '%Y-%m-%d')
        time_duration = request.form['time_duration']

        new_quiz = Quiz(title=title, chapter_id=chapter_id, date_of_quiz=date_of_quiz, time_duration=time_duration)
        db.session.add(new_quiz)
        db.session.commit()
        flash('Quiz created successfully!', 'success')
        return redirect(url_for('admin.quizzes'))

    subjects = Subject.query.all()
    return render_template('admin/quiz_creation.html', subjects=subjects)

# Route to fetch chapters for a specific subject (JSON response)
@admin_bp.route('/admin/subject/<int:subject_id>/chapters/json')
def get_chapters(subject_id):
    chapters = Chapter.query.filter_by(subject_id=subject_id).all()
    chapters_list = [{'id': chapter.id, 'name': chapter.name} for chapter in chapters]
    return jsonify(chapters_list)

# Route to edit a quiz
@admin_bp.route('/admin/quiz/edit/<int:quiz_id>', methods=['GET', 'POST'])
def quiz_edit(quiz_id):
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    if request.method == 'POST':
        if 'quiz_title' in request.form:
            # Update quiz details
            quiz.title = request.form['quiz_title']
            quiz.chapter_id = request.form['chapter_id']
            quiz.date_of_quiz = datetime.strptime(request.form['date_of_quiz'], '%Y-%m-%d')
            quiz.time_duration = request.form['time_duration']
            db.session.commit()
            flash('Quiz updated successfully!', 'success')

        return redirect(url_for('admin.quiz_edit', quiz_id=quiz.id))

    subjects = Subject.query.all()
    chapters = Chapter.query.all()
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    return render_template('admin/quiz_edit.html', quiz=quiz, subjects=subjects, chapters=chapters, questions=questions, enumerate=enumerate)

# Route to delete a quiz
@admin_bp.route('/admin/quiz/delete/<int:quiz_id>', methods=['POST'])
def quiz_delete(quiz_id):
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    db.session.delete(quiz)
    db.session.commit()
    flash('Quiz deleted successfully!', 'success')
    return redirect(url_for('admin.quizzes'))

# Route to delete a question
@admin_bp.route('/admin/question/delete/<int:question_id>', methods=['GET'])
def question_delete(question_id):
    if 'admin_logged_in' not in session:
        flash("You must be logged in as an admin to delete a question.", "danger")
        return redirect(url_for('auth.admin_login'))

    question = Question.query.get_or_404(question_id)
    quiz = question.quiz  # Get the associated quiz before deleting the question
    db.session.delete(question)
    db.session.commit()

    # Update total score of the quiz
    quiz.update_total_score()

    flash('Question deleted successfully!', 'success')
    return redirect(request.referrer or url_for('admin.quizzes'))

