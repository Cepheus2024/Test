from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from models.db import db, User
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

# Route for user registration
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        qualification = request.form['qualification']
        dob = datetime.strptime(request.form['dob'], '%Y-%m-%d').date()
        role = request.form.get('role', 'user')

        if User.query.filter_by(email=email).first():
            flash('Email already exists!', 'danger')
            return redirect(url_for('auth.register'))

        new_user = User(full_name=full_name, email=email, password=password, qualification=qualification, dob=dob, role=role)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/registration.html')

# Route for user login
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_email'] = user.email
            session['user_name'] = user.full_name

            if user.role == "admin":
                session['admin_logged_in'] = True
                flash('Admin login successful!', 'success')
                return redirect(url_for('admin.admin_dashboard'))
            else:
                flash('Login successful!', 'success')
                return redirect(url_for('user.users_dashboard'))

        flash('Invalid email or password.', 'danger')

    return render_template('auth/login.html')

# Route for admin login
@auth_bp.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        admin = User.query.filter_by(email=email).first()
        if admin and admin.role == "admin" and check_password_hash(admin.password, password):
            session['admin_logged_in'] = True
            flash('Admin login successful!', 'success')
            return redirect(url_for('admin.admin_dashboard'))

        flash('Invalid admin credentials.', 'danger')

    return render_template('admin/admin_login.html')

# Route to create a sample admin
@auth_bp.route('/create-sample-admin')
def create_sample_admin():
    admin_email = "admin@quizmaster.com"
    admin_password = generate_password_hash("admin123")
    admin_user = User.query.filter_by(email=admin_email).first()

    if not admin_user:
        new_admin = User(full_name="Admin User", email=admin_email, password=admin_password, qualification="Admin", dob=datetime(2000, 1, 1).date(), role="admin")
        db.session.add(new_admin)
        db.session.commit()
        flash('Sample admin created successfully!', 'success')
    else:
        flash('Sample admin already exists.', 'info')

    return redirect(url_for('auth.login'))

# Route for user logout
@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('auth.login'))


