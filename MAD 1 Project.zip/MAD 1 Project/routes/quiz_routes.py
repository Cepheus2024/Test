from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models.db import db, Quiz, Question, Score, User, Chapter, Option
from datetime import datetime, timedelta, date  # Add 'date' import
from utils.form_utils import get_form_data  # Import the utility function

quiz_bp = Blueprint('quiz', __name__)

# Route to create a new quiz
@quiz_bp.route('/create-quiz', methods=['GET', 'POST'])
def create_quiz():
    if request.method == 'POST':
        form_data = get_form_data('quiz_title', 'chapter_id', 'date_of_quiz', 'time_duration')
        title = form_data.get('quiz_title')
        chapter_id = form_data.get('chapter_id')
        date_of_quiz = form_data.get('date_of_quiz')
        time_duration = form_data.get('time_duration')

        if not title or not chapter_id or not date_of_quiz or not time_duration:
            flash('All fields are required.', 'danger')
            return redirect(url_for('quiz.create_quiz'))

        date_of_quiz = datetime.strptime(date_of_quiz, '%Y-%m-%d').date()

        # Prevent creating a quiz with a past date
        if date_of_quiz < date.today():
            flash('Quiz date cannot be in the past.', 'danger')
            return redirect(url_for('quiz.create_quiz'))

        new_quiz = Quiz(title=title, chapter_id=chapter_id, date_of_quiz=date_of_quiz, time_duration=time_duration)
        db.session.add(new_quiz)
        db.session.commit()

        flash('Quiz created successfully!', 'success')
        return redirect(url_for('quiz.view_quizzes'))

    chapters = Chapter.query.all()
    return render_template('quiz/create_quiz.html', chapters=chapters)

# Route to view all quizzes
@quiz_bp.route('/quizzes')
def view_quizzes():
    quizzes = Quiz.query.all()
    return render_template('quiz/view_quizzes.html', quizzes=quizzes)

# Route to delete a quiz
@quiz_bp.route('/delete-quiz/<int:quiz_id>', methods=['POST'])
def delete_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    db.session.delete(quiz)
    db.session.commit()
    flash('Quiz deleted successfully!', 'success')
    return redirect(url_for('quiz.view_quizzes'))

# Route to view quiz details
@quiz_bp.route('/quiz/<int:quiz_id>')
def quiz_details(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    return render_template('quiz/quiz_details.html', quiz=quiz)

# Route to attempt a quiz (start timer)
@quiz_bp.route('/quiz/<int:quiz_id>/attempt', methods=['GET', 'POST'])
def attempt_quiz(quiz_id):
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quiz = Quiz.query.get_or_404(quiz_id)

    # Prevent attempting a quiz after the set date
    if quiz.date_of_quiz < date.today():
        flash('This quiz is no longer available as the date has passed.', 'danger')
        return redirect(url_for('user.user_quizzes'))

    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    
    # Convert duration (HH:MM) into minutes
    quiz_duration = int(quiz.time_duration.split(':')[0]) * 60 + int(quiz.time_duration.split(':')[1])

    # Check if user already started the quiz
    if 'quiz_start_time' not in session or session.get('current_quiz_id') != quiz_id:
        session['quiz_start_time'] = datetime.now().isoformat()  # Store start time in session
        session['quiz_end_time'] = (datetime.now() + timedelta(minutes=quiz_duration)).isoformat()
        session['current_quiz_id'] = quiz_id  # Track which quiz user is attempting

    # Convert stored time from session
    start_time = datetime.fromisoformat(session['quiz_start_time'])
    end_time = datetime.fromisoformat(session['quiz_end_time'])
    time_remaining = (end_time - datetime.now()).seconds

    # If time is up, submit automatically
    if time_remaining <= 0:
        return redirect(url_for('quiz.submit_quiz', quiz_id=quiz.id))

    return render_template('user/attempt_quiz.html', quiz=quiz, questions=questions, time_remaining=time_remaining)

# Route to submit a quiz (handles auto-submit on timeout)
@quiz_bp.route('/quiz/<int:quiz_id>/submit', methods=['POST', 'GET'])
def submit_quiz(quiz_id):
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    user = User.query.filter_by(email=session['user_email']).first()
    
    # Check if time is up
    if 'quiz_end_time' in session:
        end_time = datetime.fromisoformat(session['quiz_end_time'])
        if datetime.now() >= end_time:
            flash("Time is up! Your quiz was auto-submitted.", "warning")
        del session['quiz_start_time']  # Clear session timer after submission
        del session['quiz_end_time']
        del session['current_quiz_id']

    total_score = 0
    user_answers = {}
    for question in questions:
        if question.question_type == 'mcq':
            selected_option = request.form.get(f'q{question.id}')
            if selected_option:
                user_answers[question.id] = int(selected_option)
                if int(selected_option) == question.correct_option:
                    total_score += 1  # Increment score for correct answer
        elif question.question_type == 'numerical':
            entered_answer = request.form.get(f'q{question.id}')
            if entered_answer:
                user_answers[question.id] = entered_answer
                if entered_answer == question.correct_answer:
                    total_score += 1  # Increment score for correct answer

    # Save quiz attempt
    new_score = Score(quiz_id=quiz.id, user_id=user.id, total_scored=total_score)
    db.session.add(new_score)
    db.session.commit()

    flash('Quiz submitted successfully!', 'success')
    return redirect(url_for('quiz.quiz_result', quiz_id=quiz.id, user_id=user.id, user_answers=user_answers))

# Route to view quiz results
@quiz_bp.route('/quiz/<int:quiz_id>/result/<int:user_id>')
def quiz_result(quiz_id, user_id):
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    user = User.query.get_or_404(user_id)
    score = Score.query.filter_by(quiz_id=quiz_id, user_id=user_id).first()

    return render_template('user/quiz_result.html', quiz=quiz, user=user, score=score)

# Route to delete a quiz (admin only)
@quiz_bp.route('/admin/quiz/delete/<int:quiz_id>')
def quiz_delete(quiz_id):
    if 'admin_logged_in' not in session:
        return redirect(url_for('auth.admin_login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    db.session.delete(quiz)
    db.session.commit()
    flash('Quiz deleted successfully.', 'success')
    return redirect(url_for('admin.quizzes'))

# Route to add a question to a quiz
@quiz_bp.route('/quiz/<int:quiz_id>/add-question', methods=['POST'])
def add_question(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    form_data = get_form_data('question_text', 'question_type', 'correct_option', 'correct_answer')
    question_text = form_data.get('question_text')
    question_type = form_data.get('question_type')
    correct_option = form_data.get('correct_option')
    correct_answer = form_data.get('correct_answer')

    if not question_text or not question_type:
        flash('Question text and type are required.', 'danger')
        return redirect(url_for('quiz.edit_quiz', quiz_id=quiz_id))

    new_question = Question(quiz_id=quiz.id, text=question_text, question_type=question_type)
    if question_type == 'mcq':
        if not correct_option:
            flash('Correct option is required for MCQ.', 'danger')
            return redirect(url_for('quiz.edit_quiz', quiz_id=quiz_id))
        new_question.correct_option = int(correct_option)
        db.session.add(new_question)
        db.session.commit()

        for i in range(1, 5):
            option_text = request.form.get(f'option{i}')
            if option_text:
                new_option = Option(question_id=new_question.id, text=option_text)
                db.session.add(new_option)
        db.session.commit()
    elif question_type == 'numerical':
        if not correct_answer:
            flash('Correct answer is required for numerical questions.', 'danger')
            return redirect(url_for('quiz.edit_quiz', quiz_id=quiz_id))
        new_question.correct_answer = correct_answer
        db.session.add(new_question)
        db.session.commit()

    flash('Question added successfully!', 'success')
    return redirect(url_for('quiz.edit_quiz', quiz_id=quiz_id))
