from flask import Blueprint, render_template, session, redirect, url_for, flash, request, jsonify, Response
from models.db import db, User, Quiz, Score, Question, Subject, Chapter
from datetime import datetime, date, timedelta
import os
import matplotlib.pyplot as plt
from io import BytesIO
from pytz import timezone  # Add this import for timezone handling

user_bp = Blueprint('user', __name__)

# User Dashboard
@user_bp.route('/dashboard')
def users_dashboard():
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    user = User.query.filter_by(email=session['user_email']).first()
    subjects = Subject.query.all()
    return render_template('user/users_dashboard.html', user=user, subjects=subjects)

# Fetch Chapters for a Subject
@user_bp.route('/subject/<int:subject_id>/chapters')
def get_chapters(subject_id):
    chapters = Chapter.query.filter_by(subject_id=subject_id).all()
    chapters_list = [{'id': chapter.id, 'name': chapter.name} for chapter in chapters]
    return jsonify(chapters_list)

# Fetch Quizzes for a Chapter
@user_bp.route('/chapter/<int:chapter_id>/quizzes')
def get_quizzes(chapter_id):
    quizzes = Quiz.query.filter_by(chapter_id=chapter_id).all()
    quizzes_list = [{'id': quiz.id, 'title': quiz.title, 'date_of_quiz': quiz.date_of_quiz.strftime('%d %b, %Y'), 'time_duration': quiz.time_duration} for quiz in quizzes]
    return jsonify(quizzes_list)

# View Quizzes
def filter_quizzes_by_date(quizzes):
    """Filter quizzes into active and expired based on the current date."""
    current_date = date.today()
    active_quizzes = [quiz for quiz in quizzes if quiz.date_of_quiz and quiz.date_of_quiz.date() >= current_date]
    expired_quizzes = [quiz for quiz in quizzes if quiz.date_of_quiz and quiz.date_of_quiz.date() < current_date]
    return active_quizzes, expired_quizzes

@user_bp.route('/quizzes')
def user_quizzes():
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quizzes = Quiz.query.all()
    active_quizzes, expired_quizzes = filter_quizzes_by_date(quizzes)
    return render_template('user/user_quizzes.html', active_quizzes=active_quizzes, expired_quizzes=expired_quizzes, current_date=date.today())

# Attempt Quiz
@user_bp.route('/quiz/<int:quiz_id>/attempt', methods=['GET', 'POST'])
def attempt_quiz(quiz_id):
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    
    # Convert duration (HH:MM) into minutes
    quiz_duration = int(quiz.time_duration.split(':')[0]) * 60 + int(quiz.time_duration.split(':')[1])

    # Check if user already started the quiz
    if 'quiz_start_time' not in session or session.get('current_quiz_id') != quiz_id:
        session['quiz_start_time'] = datetime.now().isoformat()  # Store start time in session
        session['quiz_end_time'] = (datetime.now() + timedelta(minutes=quiz_duration)).isoformat()
        session['current_quiz_id'] = quiz_id  # Track which quiz user is attempting

    # Convert stored time from session
    start_time = datetime.fromisoformat(session['quiz_start_time'])
    end_time = datetime.fromisoformat(session['quiz_end_time'])
    time_remaining = (end_time - datetime.now()).seconds

    # If time is up, submit automatically
    if time_remaining <= 0:
        return redirect(url_for('user.submit_quiz', quiz_id=quiz.id))

    return render_template('user/attempt_quiz.html', quiz=quiz, questions=questions, time_remaining=time_remaining)

# Submit Quiz (Handles Auto-Submit on Timeout)
@user_bp.route('/quiz/<int:quiz_id>/submit', methods=['POST', 'GET'])
def submit_quiz(quiz_id):
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    user = User.query.filter_by(email=session['user_email']).first()
    
    # Check if time is up
    if 'quiz_end_time' in session:
        end_time = datetime.fromisoformat(session['quiz_end_time'])
        if datetime.now() >= end_time:
            flash("Time is up! Your quiz was auto-submitted.", "warning")
        del session['quiz_start_time']
        del session['quiz_end_time']
        del session['current_quiz_id']

    total_score = 0
    user_answers = {}
    for question in questions:
        if question.question_type == 'mcq':
            selected_option = request.form.get(f'q{question.id}')
            user_answers[question.id] = {
                'user_answer': int(selected_option) if selected_option else None,
                'correct_answer': question.correct_option,
                'marks': question.marks if selected_option and int(selected_option) == question.correct_option else 0
            }
            if selected_option and int(selected_option) == question.correct_option:
                total_score += question.marks  # Add marks for correct answer
        elif question.question_type == 'numerical':
            entered_answer = request.form.get(f'q{question.id}')
            user_answers[question.id] = {
                'user_answer': entered_answer,
                'correct_answer': question.correct_answer,
                'marks': question.marks if entered_answer and entered_answer.strip() == question.correct_answer.strip() else 0
            }
            if entered_answer and entered_answer.strip() == question.correct_answer.strip():
                total_score += question.marks  # Add marks for correct answer

    # Ensure all questions are in user_answers, even if unanswered
    for question in questions:
        if question.id not in user_answers:
            user_answers[question.id] = {
                'user_answer': None,
                'correct_answer': question.correct_option if question.question_type == 'mcq' else question.correct_answer,
                'marks': 0
            }

    # Save quiz attempt
    existing_score = Score.query.filter_by(quiz_id=quiz.id, user_id=user.id).first()
    if existing_score:
        existing_score.total_scored = total_score  # Update the score if it already exists
    else:
        new_score = Score(quiz_id=quiz.id, user_id=user.id, total_scored=total_score)
        db.session.add(new_score)
    db.session.commit()

    flash('Quiz submitted successfully!', 'success')

    # Redirect to the quiz submission results page
    return render_template('user/quiz_submission.html', quiz=quiz, user=user, questions=questions, user_answers=user_answers)

# View Scores
@user_bp.route('/quiz/results')
def quiz_results():
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    user = User.query.filter_by(email=session['user_email']).first()

    # Fetch all scores sorted by latest attempts
    scores = Score.query.filter_by(user_id=user.id).order_by(Score.time_stamp_of_attempt.desc()).all()
    quizzes = {score.quiz_id: Quiz.query.get(score.quiz_id) for score in scores}

    # Convert timestamps to IST
    for score in scores:
        score.time_stamp_of_attempt = score.time_stamp_of_attempt.astimezone(timezone('Asia/Kolkata'))

    return render_template('user/quiz_result.html', scores=scores, quizzes=quizzes)

# User Summary Statistics
@user_bp.route('/summary', methods=['GET'])
def user_summary_statistics():
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    user = User.query.filter_by(email=session['user_email']).first()
    subjects = Subject.query.all()
    subject_id = request.args.get('subject_id')
    chapter_id = request.args.get('chapter_id')
    selected_subject = Subject.query.get(subject_id) if subject_id else None
    selected_chapter = Chapter.query.get(chapter_id) if chapter_id else None

    if selected_chapter:
        quizzes = Quiz.query.filter_by(chapter_id=selected_chapter.id).all()
    elif selected_subject:
        quizzes = Quiz.query.filter(Quiz.chapter.has(subject_id=selected_subject.id)).all()
    else:
        quizzes = []

    scores = Score.query.filter(Score.quiz_id.in_([quiz.id for quiz in quizzes]), Score.user_id == user.id).order_by(Score.time_stamp_of_attempt.asc()).all()

    total_quizzes = len(scores)
    highest_score = max([s.total_scored for s in scores], default=0)
    average_score = round(sum([s.total_scored for s in scores]) / total_quizzes, 2) if total_quizzes > 0 else 0

    # Generate Performance Chart URL
    chart_url = url_for('user.generate_performance_chart', user_id=user.id, subject_id=subject_id, chapter_id=chapter_id)

    return render_template('user/user_summary_statistics.html',
                           subjects=subjects,
                           selected_subject=selected_subject,
                           selected_chapter=selected_chapter,
                           total_quizzes=total_quizzes,
                           highest_score=highest_score,
                           average_score=average_score,
                           chart_url=chart_url)

@user_bp.route('/generate_performance_chart/<int:user_id>')
def generate_performance_chart(user_id):
    subject_id = request.args.get('subject_id')
    chapter_id = request.args.get('chapter_id')
    selected_subject = Subject.query.get(subject_id) if subject_id else None
    selected_chapter = Chapter.query.get(chapter_id) if chapter_id else None

    if selected_chapter:
        quizzes = Quiz.query.filter_by(chapter_id=selected_chapter.id).all()
    elif selected_subject:
        quizzes = Quiz.query.filter(Quiz.chapter.has(subject_id=selected_subject.id)).all()
    else:
        quizzes = []

    scores = Score.query.filter(Score.quiz_id.in_([quiz.id for quiz in quizzes]), Score.user_id == user_id).order_by(Score.time_stamp_of_attempt.asc()).all()

    if not scores:  # Check if there are no scores
        # Return a placeholder image or message
        plt.figure(figsize=(12, 6))
        plt.text(0.5, 0.5, 'No Data Available', fontsize=20, ha='center', va='center')
        plt.axis('off')  # Turn off axes for the placeholder
        img = BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plt.close()
        return Response(img.getvalue(), mimetype='image/png')

    quiz_dates = [s.time_stamp_of_attempt.strftime('%d-%b-%Y') for s in scores]
    scores_values = [max(s.total_scored, 0) for s in scores]  # Ensure no negative values

    plt.figure(figsize=(12, 6))  # Adjusted size for better responsiveness
    bar_width = 0.6  # Adjusted bar width for better spacing

    # Plot user scores
    plt.bar(quiz_dates, scores_values, width=bar_width, color='skyblue', label='User Score', align='center')

    plt.title('User Quiz Performance', fontsize=16)
    plt.xlabel('Quiz Date', fontsize=12)
    plt.ylabel('Score', fontsize=12)
    plt.xticks(rotation=45, fontsize=10)  # Rotate x-axis labels for better readability
    plt.yticks(fontsize=10)
    plt.ylim(bottom=0)  # Explicitly set the y-axis lower limit to 0
    plt.xlim(left=0)  # Explicitly set the x-axis lower limit to 0
    plt.legend(fontsize=10)
    plt.tight_layout()  # Ensure everything fits within the figure
    plt.grid(axis='y', linestyle='--', alpha=0.7)

    # Save graph to a BytesIO object
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()

    return Response(img.getvalue(), mimetype='image/png')

@user_bp.route('/search')
def search_quizzes():
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    query = request.args.get('query', '').strip()
    if not query:
        return redirect(url_for('user.user_quizzes'))

    quizzes = Quiz.query.join(Chapter).join(Subject).filter(
        (Quiz.title.ilike(f"%{query}%")) |
        (Chapter.name.ilike(f"%{query}%")) |
        (Subject.name.ilike(f"%{query}%"))
    ).all()

    active_quizzes, expired_quizzes = filter_quizzes_by_date(quizzes)
    return render_template('user/user_quizzes.html', 
                           active_quizzes=active_quizzes, 
                           expired_quizzes=expired_quizzes, 
                           search_query=query, 
                           current_date=date.today())

@user_bp.route('/quiz/<int:quiz_id>/questions')
def view_quiz_questions(quiz_id):
    if 'user_email' not in session:
        return redirect(url_for('auth.login'))

    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()

    return render_template('user/view_quiz_questions.html', quiz=quiz, questions=questions)
