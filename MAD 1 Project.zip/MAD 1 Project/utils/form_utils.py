from flask import request

def get_form_data(*keys):
    """
    Safely get form data for the given keys.
    Returns a dictionary with the keys and their corresponding values.
    If a key is not found, its value will be None.
    """
    return {key: request.form.get(key) for key in keys}
